export default Credential={
    email:'marc.reynolds21@ethereal.email',
    password:'XvWFbqrjd11DK39uc1'
}