
const express=require('express')
const nodemailer=require('nodemailer')

PORT=5000;
const app=express()

let transporter=nodemailer.createTransport({
    host:'smtp.ethereal.email',
    port :587,
    secure:false,
    auth:{
        user: 'marc.reynolds21@ethereal.email',
        pass:'XvWFbqrjd11DK39uc1',
    },
})

app.get("/sendmail",(req,res)=>{

    let mailOptions={
        from :"guravsamiksha17@gmail.com",
        to:'guravsamiksha17@gmail.com',
        subjeect:'hello',
        text:'welcome'
    }
    transporter.sendMail(mailOptions,function(error,info){
        if(error){
            console.log(error);

        }
        else{
            console.log("Email sent" +info.response)
        }
    })
})
app.listen(PORT,(err)=>{
    console.log('working on 5000')
})