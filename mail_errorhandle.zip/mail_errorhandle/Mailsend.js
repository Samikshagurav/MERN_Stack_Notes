const sendGridMail = require('@sendgrid/mail');
sendGridMail.setApiKey('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');

function getMessage() {
  const body = 'This is a test email using SendGrid from Node.js';
  return {
    to: 'guravsamiksha17@gmail.com',
    from: 'odessa.king86@ethereal.email    ',
    subject: 'Test email with Node.js and SendGrid',
    text: body,
    html: `<strong>${body}</strong>`,
  };
}

async function sendEmail() {
  try {
    await sendGridMail.send(getMessage());
    console.log('Test email sent successfully');
  } catch (error) {
    console.error('Error sending test email');
    console.error(error);
    if (error.response) {
      console.error(error.response.body)
    }
  }
}

(async () => {
  console.log('Sending test email');
  await sendEmail();
})();
