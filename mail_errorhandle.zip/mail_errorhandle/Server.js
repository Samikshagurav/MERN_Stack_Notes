const express=require('express');
PORT=9000;
const app=express();
app.get('/',(req,res)=>{
    // throw new Error("Something Went wrong")
    res.json({"msg":"default Route"})
})
//handling error in route handler
app.get("/about",(req,res,next)=>{
    try{
        res.send("This is about route")
    }
    catch(error){
        res.status(500).send({
            error:{
                status:500,
                message:"Internal Server Error"
            }
        })
    }
})
//handling error
app.use((req,res,next)=>{
    res.status(404).send({
        status:404,
        error:'Not Found'
    })
})
//custom middleware
app.use((error,req,res,next)=>{
    console.error(error.stack)
    res.status(500).send("Something Broken")
})
app.listen(PORT,(err)=>{
    if(err)throw err
    console.log('working on 9000')
})