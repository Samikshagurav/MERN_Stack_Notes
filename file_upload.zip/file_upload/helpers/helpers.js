const imageFilter=(req,file,cb)=>{
    //accept images only
    if(!file.originalname.match(/\.(jpg|JPG|jpeg|JPEG|png|PNG|gif|GIF)$/))
    {
        req.fileValidationError=`<h1>Only Image files are allowed<h1>`;
        return cb(new Error(`<h1>Only Image files are allowed<h1>`),false);
    }
    cb(null,true);
};
exports.imageFilter=imageFilter