const express=require('express');
const multer=require('multer');
const path=require('path')
const PORT=8888;
const app=express();
const helpers=require('./helpers/helpers')
app.set("view engine","ejs")

app.use(express.static('uploads'))


const storage=multer.diskStorage({
    destination:(req,res,cb)=>{
        cb(null,'uploads/')
    },
    filename:(req,file,cb)=>{
        cb(null,file.fieldname+"-" +Date.now()+path.extname(file.originalname))
     
    }
})
app.get("/",(req,res)=>{
    res.render('upload')
})

app.post('/fileupload',(req,res)=>{
   let upload=multer({storage:storage,fileFilter:helpers.imageFilter}).single('myfile');
   upload(req,res,(err)=>{
       if(req.fileValidationError){
           res.send(req.fileValidationError)

       }
      else if(!req.file){
           res.send("Please select a file")

       }else if(err){
           res.send('some uploading error')
       }
       else{
        //    res.send("you have uploaded the file: " +req.file.path);
        res.send(`You have uploaded the file : <hr/> <img src="${req.file.filename}" width="300" height="300"/>`);
    }
   })

})


app.get("/multiplefile",(req,res)=>{
    res.render('multiple_file_upload')
})



app.post('/multupload',(req,res)=>{
    let upload=multer({storage:storage,fileFilter:helpers.imageFilter}).array('multiple_images',14)

    upload(req,res,(err)=>{
        if(req.fileValidationError){
            res.send(req.fileValidationError)
 
        }
       else if(!req.files){
            res.send("Please select a file")
 
        }else if(err){
            res.send('some uploading error')
        }
        else{
            let result="";
          
            // res.send("you have uploaded the file: " +req.file.path);
         const files=req.files;
         let  len=files.length;
         for(index=0; index<len;++index){
             result+=`<img src="${files[index].filename}" width=300 height=300/>`;
         }
         res.send(result);
      
     }
    })
 
 })
 
app.listen(PORT,(err)=>{
    if(err) throw err
    console.log('woring on 8888')
})